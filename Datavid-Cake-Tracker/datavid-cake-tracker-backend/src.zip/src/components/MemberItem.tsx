import '../styles/components/MemberItem.scss';
import React from 'react';
import { Member } from '../interfaces/Member';

interface MemberItemProps {
    member: Member;
}

const MemberItem: React.FC<MemberItemProps> = ({ member }) => {
    return (
        <li className={`member-item ${getBirthdayClass(member.days_until_birthday)}`}>
            {member.first_name} {member.last_name} - {new Date(member.birth_date).toLocaleDateString()} - {member.days_until_birthday} days until birthday
        </li>
    );
};

const getBirthdayClass = (days: number): string => {
    if (days <= 7) return 'red';
    if (days <= 21) return 'orange';
    return 'green';
};

export default MemberItem;
